let telaAtual = 0; // 0: menu, 1: plantio, 2: crescendo, 3: colheita, 4: transporte, 5: cidade
let batatasPlantadas = [];
let umidadeSolo = 50; // de 0 a 100
let nutrientesSolo = 50; // de 0 a 100
let diasCrescimento = 0;
let mostrarPraga = false;
let caminhãoX;

function setup() {
  createCanvas(900, 600);
  caminhãoX = -100; // Começa fora da tela
}

function draw() {
  background(220); // Cor de fundo padrão

  if (telaAtual === 0) {
    drawMenu();
  } else if (telaAtual === 1) {
    drawPlantio();
  } else if (telaAtual === 2) {
    drawCrescimento();
  } else if (telaAtual === 3) {
    drawColheita();
  } else if (telaAtual === 4) {
    drawTransporte();
  } else if (telaAtual === 5) {
    drawCidade();
  }
}

function mousePressed() {
  if (telaAtual === 0) {
    // Lógica para clicar nos botões do menu
    if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > height / 2 - 30 && mouseY < height / 2 + 10) {
      telaAtual = 1; // Iniciar Plantio
    }
  } else if (telaAtual === 1) {
    // Lógica para "plantar" ao clicar no solo
    if (mouseY > height / 2) {
      batatasPlantadas.push({ x: mouseX, y: mouseY, estagio: 0 }); // Estágio de crescimento da batata
      if (batatasPlantadas.length >= 5) { // Plantou algumas, vai para a próxima fase
        telaAtual = 2;
      }
    }
  } else if (telaAtual === 2) {
    // Lógica para "remover praga" ou "regar"
    if (mostrarPraga && dist(mouseX, mouseY, width * 0.7, height * 0.4) < 30) {
      mostrarPraga = false; // Remove a praga
    }
    // Exemplo de regar ao clicar na água (simulado)
    if (mouseX < 50 && mouseY < 50) { // Canto superior esquerdo para regar
        umidadeSolo = min(100, umidadeSolo + 10);
    }
  } else if (telaAtual === 3) {
    // Lógica para "colher" a batata
    for (let i = batatasPlantadas.length - 1; i >= 0; i--) {
      if (dist(mouseX, mouseY, batatasPlantadas[i].x, batatasPlantadas[i].y) < 20) {
        batatasPlantadas.splice(i, 1); // Remove a batata colhida
        if (batatasPlantadas.length === 0) {
          telaAtual = 4; // Vai para transporte
        }
      }
    }
  }
}

function drawMenu() {
  fill(0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('A Jornada da Batata', width / 2, height / 2 - 100);

  fill(50, 150, 50); // Botão "Iniciar Plantio"
  rect(width / 2 - 80, height / 2 - 30, 160, 40);
  fill(255);
  textSize(20);
  text('Iniciar Plantio', width / 2, height / 2 - 10);
}

function drawPlantio() {
  background(135, 206, 235); // Céu
  fill(139, 69, 19); // Terra
  rect(0, height / 2, width, height / 2);

  fill(0);
  textSize(20);
  text('Clique para plantar as batatas!', width / 2, 50);

  for (let b of batatasPlantadas) {
    fill(100, 70, 40); // Cor da batata-semente
    ellipse(b.x, b.y, 25, 20);
  }
}

function drawCrescimento() {
  background(135, 206, 235); // Céu
  fill(139, 69, 19); // Terra
  rect(0, height / 2, width, height / 2);

  diasCrescimento++;
  umidadeSolo = max(0, umidadeSolo - 0.05); // Diminui umidade com o tempo

  // Desenha as batatas crescendo
  for (let b of batatasPlantadas) {
    fill(50, 150, 50); // Cor da planta
    let alturaPlanta = map(b.estagio, 0, 100, 0, 80); // Crescimento
    rect(b.x - 5, b.y - alturaPlanta, 10, alturaPlanta);

    // Atualiza estágio de crescimento
    b.estagio = min(100, b.estagio + 0.1);
  }

  // Medidor de umidade
  fill(0, 0, 200);
  rect(width - 150, 20, umidadeSolo, 20);
  fill(0);
  text('Umidade: ' + floor(umidadeSolo) + '%', width - 250, 35);
  
  // Exemplo de praga aleatória
  if (random(0, 1000) < 1 && !mostrarPraga) { // 0.1% de chance de aparecer praga
      mostrarPraga = true;
  }
  if (mostrarPraga) {
      fill(255, 0, 0); // Ícone da praga
      ellipse(width * 0.7, height * 0.4, 20, 20);
      fill(0);
      textSize(14);
      text('Praga! Clique para remover!', width * 0.7, height * 0.4 + 25);
  }

  fill(0);
  textSize(20);
  text('Dias: ' + floor(diasCrescimento / 60), 50, 50); // 60 frames = 1 dia
  
  // Condição para ir para a colheita
  if (diasCrescimento / 60 > 30 && batatasPlantadas.every(b => b.estagio >= 90)) { // Ex: 30 dias de cultivo e plantas maduras
    telaAtual = 3;
    diasCrescimento = 0; // Reseta para próxima fase
  }
}

function drawColheita() {
  background(135, 206, 235); // Céu
  fill(139, 69, 19); // Terra
  rect(0, height / 2, width, height / 2);

  fill(0);
  textSize(20);
  text('Clique nas batatas para colher!', width / 2, 50);

  // Desenha as batatas "expostas" para colheita
  for (let b of batatasPlantadas) {
    fill(100, 70, 40); // Cor da batata colhida
    ellipse(b.x, b.y, 40, 30); // Batata maior
  }

  // Desenha o caminhão para "receber" as batatas
  fill(150, 100, 50);
  rect(width - 200, height - 100, 180, 80);
  fill(0);
  rect(width - 180, height - 20, 20, 20); // Roda
  rect(width - 60, height - 20, 20, 20); // Roda
  fill(255);
  text('Caminhão', width - 110, height - 120);
}

function drawTransporte() {
  background(135, 206, 235); // Céu
  fill(100, 100, 100); // Estrada
  rect(0, height / 2 + 50, width, 50);

  // Animação do caminhão
  fill(150, 100, 50); // Caminhão
  rect(caminhãoX, height / 2, 100, 60);
  fill(0);
  rect(caminhãoX + 10, height / 2 + 50, 15, 15);
  rect(caminhãoX + 75, height / 2 + 50, 15, 15);

  caminhãoX += 2; // Move o caminhão
  if (caminhãoX > width + 50) {
    telaAtual = 5; // Chegou na cidade
    caminhãoX = -100; // Reseta para próxima vez
  }

  fill(0);
  textSize(20);
  text('Transportando para a cidade...', width / 2, 50);
}

function drawCidade() {
  background(200, 200, 255); // Céu da cidade
  fill(150); // Prédios
  rect(50, height - 200, 100, 150);
  rect(200, height - 250, 120, 200);
  rect(400, height - 180, 80, 130);

  // Representação da feira/supermercado
  fill(180, 220, 180); // Cor da barraca
  rect(width / 2 - 150, height - 100, 300, 80);
  fill(100, 70, 40);
  ellipse(width / 2 - 100, height - 60, 40, 30); // Batata na banca
  ellipse(width / 2, height - 60, 40, 30);
  ellipse(width / 2 + 100, height - 60, 40, 30);

  fill(0);
  textSize(24);
  text('A batata chegou à sua mesa!', width / 2, 50);
  textSize(16);
  text('Valorize cada etapa do processo!', width / 2, 80);

  // Botão para reiniciar
  fill(50, 150, 50);
  rect(width / 2 - 60, height - 50, 120, 30);
  fill(255);
  textSize(16);
  text('Reiniciar', width / 2, height - 35);
}
